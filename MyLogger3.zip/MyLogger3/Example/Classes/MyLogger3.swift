//
//  MyLogger3.swift
//  MyLogger3_Tests
//
//  Created by Vsevolod Melnik on 18.11.2021.
//  Copyright © 2021 CocoaPods. All rights reserved.
//

import Foundation

public struct MyLogger3 {
    public static func log(_ s: String) {
        print("MyLogger3 from pod (\(Date())): \(s)")
    }
}
